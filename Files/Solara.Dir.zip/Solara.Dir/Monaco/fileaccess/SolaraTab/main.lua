local body = request {
        Url = "https://httpbin.org",
        Method = "",
        Headers = {
            ["Content-Type"] = "text/plain",
            ["Authorization"] = ''
        },
        Body = '',
    }.Body
print(body)