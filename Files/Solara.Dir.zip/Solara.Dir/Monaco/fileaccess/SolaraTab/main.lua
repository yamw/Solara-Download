loadstring([[
Instance.new("Hint", workspace).Text = "test"
]])()
