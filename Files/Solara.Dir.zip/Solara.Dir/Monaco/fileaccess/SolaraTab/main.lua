while true do  
    task.wait(.2)
    writefile("test.txt", "1")
end